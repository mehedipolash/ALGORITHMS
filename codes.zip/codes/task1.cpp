#include<iostream>
using namespace std;
int main()
{
    int arr[15], i, num, index;

    cout<<"Enter 15 Numbers: ";
    for(i=0; i<15; i++)
    {
       cin>>arr[i];
    }

    cout<<" Enter a Number to Search: ";
    cin>>num;
    for(i=0; i<15; i++)
    {
        if(arr[i]==num)
        {
            index = i;
            break;
        }
    }
    if(num==arr[i])
    {
        cout<<"Data found at index "<<index;
        cout<<endl;
    }
    else
    {
      cout<<"Data not found in the array." <<endl;
    }

    return 0;
}


