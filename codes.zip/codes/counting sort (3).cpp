#include <iostream>
using namespace std;

void countingSort(int array[], int size)
 {
    int count[10] = {0};


    for (int i = 0; i < size; i++)
        {
        count[array[i]]++;
        }


    for (int i = 0; i < 10; i++)
        {
          while (count[i] > 0)
           {
             cout << i << " ";
             count[i]--;
           }
        }
    cout << endl;
}

int main() {
    int array[] = {0, 3, 1, 5, 7, 9, 6, 9, 0, 4, 3, 0, 2, 8, 8, 9, 3, 4, 6, 5};
    int n = sizeof(array) / sizeof(array[0]);

    countingSort(array, n);

    return 0;
}

