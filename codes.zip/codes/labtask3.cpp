#include <iostream>
using namespace std;

int binarySearch(int arr[], int size, int key) {
    int left = 0;
    int right = size - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;

        if (arr[mid] == key) {
            return mid;
        } else if (arr[mid] < key) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    return -1;
}

int main() {
    int arr[] = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47, 49};
    int size = sizeof(arr) / sizeof(arr[0]);

    int key1 = 17;
    int index1 = binarySearch(arr, size, key1);
    if (index1 != -1) {
        cout << index1 << endl;
    } else {
        cout << "Not Found." << endl;
    }

    int key2 = 37;
    int index2 = binarySearch(arr, size, key2);
    if (index2 != -1) {
        cout << index2 << endl;
    } else {
        cout << "Not Found." << endl;
    }

    int key3 = 42;
    int index3 = binarySearch(arr, size, key3);
    if (index3 != -1) {
        cout << index3 << endl;
    } else {
        cout << "Not Found." << endl;
    }


    for (int i = 0; i < size; ++i) {
        if (arr[i] >= 17) {
            cout << arr[i] << " ";
        }
    }
    cout << endl;


    for (int i = 0; i < size; ++i) {
        if (arr[i] <= 37) {
            cout << arr[i] << " ";
        }
    }
    cout << endl;

    return 0;
}
