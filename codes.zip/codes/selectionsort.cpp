#include<iostream>
using namespace std;

 void printArray(int arr[],int size)
 {
    for(int i=0;i<size;i++)
        {
        cout<<arr[i]<<" ";
        }
        cout<<endl;
 }

void selectionsort(int arr[],int size)
{
    for(int i=0; i<size-1;i++)

    {
        int minimumindex = i;

        for(int j=i+1; j<size; j++)
        {
            if(arr [minimumindex]>arr[j])
            {
                minimumindex=j;
            }
        }

        int temp= arr[i];
        arr[i]=arr[minimumindex];
        arr[minimumindex]=temp;


    }
}





int main()
{
    int size = 5;
    int data[] = {9,13,15,11,2};

    cout<<"Unsorted Data"<<endl;
    printArray(data,5);


    selectionsort(data,5);


    cout<<"Sorted Data"<<endl;
    printArray(data,5);

return 0;
}
